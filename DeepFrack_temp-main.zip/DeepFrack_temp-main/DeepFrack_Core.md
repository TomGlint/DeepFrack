# The DEEPFRACK CORE Scheduler  
This markdown sheds some light on the implementation of the DeepFrack core and also explains some of the assumptions and approximations made. To obtaint a deeper understanding, one is advised to look into the paper and the source code.  
   
It is now multithreaded, and much faster!
Please checkout DeepFrack_fast.py for the fast version, as compared to DeepFrack_simple.py