Date: 11/3/24
Added the following changes:
1) Converted the application to a multi threaded one.
2) Imporved usability and added logo anf other aethetic features.
3) Added VGG-Simba Example.
4) [BETA] Developed a dataset of all architecture and workload files available in a database. This database is queried by normal user text promts. So now instead of giving the file path of the YAML files, the user can simply give the name of the workload and the architecture.
5) Added Logo.
